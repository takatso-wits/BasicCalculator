package com.example.basiccalculator;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    private EditText etScreen, etDispalay;
    private Button btn1;
    private Button btn2;
    private Button btn3;
    private Button btn4;
    private Button btn5;
    private Button btn6;
    private Button btn7;
    private Button btn8;
    private Button btn9;
    private Button btn0;
    private Button btnDot;
    private Button btnClear;
    private Button btnDivision;
    private Button btnMuliply;
    private Button btnAddition;
    private Button btnSubtraction;
    private Button btnEquals;

    private Double val1;
    private Double val2;
    private String v1;
    private String v2;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);



        etScreen = (EditText)findViewById(R.id.screen);
        etDispalay = (EditText)findViewById(R.id.screenDisplay);

        /***
         * Make Text not Clickable
         * */
        etScreen.setEnabled(false);
        etDispalay.setEnabled(false);



        /**
         * GET ALL THE NUMBERS
         * */
        btn1 = (Button)findViewById(R.id.btn1);
        btn2 = (Button)findViewById(R.id.btn2);
        btn3 = (Button)findViewById(R.id.btn3);
        btn4 = (Button)findViewById(R.id.btn4);
        btn5 = (Button)findViewById(R.id.btn5);
        btn6 = (Button)findViewById(R.id.btn6);
        btn7 = (Button)findViewById(R.id.btn7);
        btn8 = (Button)findViewById(R.id.btn8);
        btn9 = (Button)findViewById(R.id.btn9);
        btn0 = (Button)findViewById(R.id.btn0);


        /**
         * GET ALL THE OPERATIONS
         * */
        btnMuliply = (Button)findViewById(R.id.btnMult);
        btnDivision = (Button)findViewById(R.id.btnDiv);
        btnAddition = (Button)findViewById(R.id.btnAdd);
        btnSubtraction = (Button)findViewById(R.id.btnMin);
        btnEquals = (Button)findViewById(R.id.btnEqual);
        btnClear = (Button)findViewById(R.id.btnClear);


        /**
         * SET ONCLICKLISTENERS
         * */
        btn1.setOnClickListener(this);
        btn2.setOnClickListener(this);
        btn3.setOnClickListener(this);
        btn4.setOnClickListener(this);
        btn5.setOnClickListener(this);
        btn6.setOnClickListener(this);
        btn7.setOnClickListener(this);
        btn8.setOnClickListener(this);
        btn9.setOnClickListener(this);
        btn0.setOnClickListener(this);


        btnMuliply.setOnClickListener(this);
        btnDivision.setOnClickListener(this);
        btnSubtraction.setOnClickListener(this);
        btnEquals.setOnClickListener(this); //This might not even work...
        btnAddition.setOnClickListener(this);
        btnClear.setOnClickListener(this);

    }

    @Override
    public void onClick(View v) {

        if (v == btnClear){
            etDispalay.setText("");
            etScreen.setText("");
        }

        if (v == btn1){
            etScreen.append("1");

        }
        if (v == btn2){
            etScreen.append("2");

        }
        if (v == btn3){
            etScreen.append("3");

        }
        if (v == btn4){
            etScreen.append("4");

        }
        if (v == btn5){
            etScreen.append("5");

        }
        if (v == btn6){
            etScreen.append("6");

        }
        if (v == btn7){
            etScreen.append("7");

        }
        if (v == btn8){
            etScreen.append("8");

        }
        if (v == btn9){
            etScreen.append("9");

        }
        if (v == btn0){
            etScreen.append("0");

        }

        if (v == btnAddition){
            val1 = Double.parseDouble(etScreen.getText().toString());
            v1 = etScreen.getText().toString();
            etScreen.setText("");
            etDispalay.setText(v1.concat(" + "));


            btnEquals.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    double total;
                    v2 = etScreen.getText().toString();
                    if(!v2.isEmpty())
                        val2 = Double.parseDouble(etScreen.getText().toString());
                    else{
                        Toast.makeText(MainActivity.this, "Action Not Allowed", Toast.LENGTH_SHORT).show();
                        return;
                    }

                    total = val1 + val2;
                    etDispalay.append(v2.concat(" = ") + total);
                    etScreen.setText("");

                }
            });


        }

    }
}
